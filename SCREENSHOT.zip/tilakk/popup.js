
document.getElementById('screenshotButton').addEventListener('click', () => {
  chrome.tabs.captureVisibleTab(null, {}, (dataUrl) => {
    if (chrome.runtime.lastError) {
      console.error('Error capturing screenshot:', chrome.runtime.lastError);
      return;
    }
    chrome.downloads.download({
      url: dataUrl,
      filename: 'screenshot.png'
    });
  });
});

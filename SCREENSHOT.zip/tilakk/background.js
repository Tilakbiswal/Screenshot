
chrome.action.onClicked.addListener((tab) => {
  chrome.tabs.captureVisibleTab(null, { format: 'png' }, (dataUrl) => {
    if (chrome.runtime.lastError) {
      console.error('Error capturing screenshot:', chrome.runtime.lastError);
      return;
    }

    chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: downloadScreenshot,
      args: [dataUrl]
    });
  });
});